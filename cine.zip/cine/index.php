<?php require 'head.php' ?>
<body>
    <header class="header">
       <a href="/"><img src="assets/img/logo.png" alt="logo"></a>
       <div class="line-header">
            <?php if (isset($_SESSION['data-user'])) {
                $datauser = $_SESSION['data-user'];
                $typeuser = $_SESSION['data-user']->IDTYPEUSER;
                if ($typeuser == 2) {
            ?>
                <nav class="menu">
                    <a href="index.php">Inicio</a>
                    <a href="#">Reservaciones</a>
                </nav>
            <?php } ?>
                <nav class="user-content close-menu">
                    <div class="user-data">
                        <div class="user">
                            <img src="assets/users-img/<?=$datauser->IMG?>" alt="img user">
                            <div>
                                <small id="name"><?=$datauser->NOMBRE.' '.$datauser->APELLIDO?></small><br>
                                <small id="typeuser"><i class="fa fa-user"></i><?=$datauser->TYPEUSER?></small>  
                            </div>
                        </div>
                        <i class="fa fa-caret-down"></i>
                    </div>
                    <div class="user-menu">
                        <li><a href="logout.php">Cerrar Sessión</a></li>
                    </div>
                </nav>
            <?php }else{ ?>
                <nav class="menu">
                    <a href="index.php">Inicio</a>
                </nav>
                <nav class="in-buttons">
                    <a href="login.php">Iniciar Sessión</a>
                    <a href="sing-in.php">Registrarse</a>
                </nav>
            <?php } ?>
        </div>
    </header>
    <aside class="wrapper">
        <h1>FUNCIONES</h1>
        <?php 
            $typeuser = null;
            if (isset($_SESSION['data-user'])) {
                $typeuser = $_SESSION['data-user']->IDTYPEUSER;
            }
            switch ($typeuser) {
                case 1:
        ?>               
            <div class="main-content">
                <div class="mb-center">
                    <button class="basic-button" data-toggle="modal" data-target="#functionModal" id="add">Añadir función</button>
                    <table id="tableFunctions">
                        <thead>
                            <tr>
                                <th>Nombre</th>
                                <th>Fecha de inicio</th>
                                <th>Fecha de finalizacion</th>
                                <th>Capacidad</th>
                                <th>Lugar</th>
                                <th colspand="2">Acciones</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </div>
            </div>
            <div class="modal fade" id="functionModal" tabindex="-1" role="dialog" aria-labelledby="modal" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="ModalLongTitle"></h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body"></div>
                    <div class="modal-footer">
                        <button type="button" class="basic-button green-button" id="save">Guardar</button>
                        <button type="button" class="basic-button red-button" data-dismiss="modal">Cerrar</button>
                    </div>
                    </div>
                </div>
            </div>
        <?php  
            break;
                
            default:
        ?>
        <section class="container"></section>
        <div class="modal fade" id="modal" tabindex="-1" role="dialog" aria-labelledby="modal" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered modal-mid" role="document">
                <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLongTitle"></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body modal-flex">
                    <div class="card">
                        <img id="cover" src="" alt="caratula">
                        <h3 id="modalTitleFilm"></h3>
                        <small id="gender"></small>
                    </div>
                    <div class="card-description">
                        <h1>Descripción:</h1>
                        <p class="description"></p>
                        <h1>Detalles de la función:</h1>
                        <p id="startDate"></p>
                        <p id="endDate"></p>
                        <p id="location"></p>
                        <p id="address"></p>
                        <p id="capacity"></p>   
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="basic-button green-button" id="reservar">Reservar</button>
                    <button type="button" class="basic-button red-button" data-dismiss="modal">Cerrar</button>
                </div>
                </div>
            </div>
        </div>
        <?php 
                break;
            } 
        ?>
    </aside>
</body>
</html>