<?php 
    require 'model/connection.php';
    class ValidateLoginModel extends Connection {
        private $data;
        public function __construct() {
            parent::__construct();
        }

        public function validate($user, $pass) {
            $query = "SELECT * FROM users u, type_user tu WHERE (user = '$user' or email = '$user') AND pass = '$pass' AND u.id_type_user = tu.id_type_user";
            $result = $this->conn->query($query);
            $row = $result->fetch_array();
            if (!empty($row)) {
                $this->data = (object)array(
                    'ID'                => $row['id_users'],
                    'NOMBRE'            => $row['name'],
                    'APELLIDO'	        => $row['last_name'],
                    'USUARIO'	        => $row['user'],
                    'CORREO'            => $row['email'],
                    'IDTYPEUSER'        => $row['id_type_user'],
                    'TYPEUSER'          => $row['description'],
                    'IMG'               => $row['img'],
                    'FECHA_REGISTRO'    => $row['registration_date']
                );
                return true;
            }else{
                $this->data = null;
                return false;
            }
        }

        public function getData(){
            return $this->data;
        }

        public function register($data){
            $query = "SELECT * FROM users WHERE user = '$data->user' or email = '$data->email'";
            $result = $this->conn->query($query);
            $row = $result->fetch_array();
            $pass = hash('sha512', $data->pass);
            $date = date("Y-m-d h:i:s");
            if ($row[0] < 1) {
                $query = "INSERT INTO users(name, last_name, user, email, pass, img, id_type_user, registration_date)VALUES(
                    '$data->name',
                    '$data->lastName',
                    '$data->user',
                    '$data->email',
                    '$pass',
                    'default.jpg',
                    2,
                    '$date'
                )";
                $this->conn->query($query);
                return true;
            }else{
                return false;
            }
        }
    }
?>