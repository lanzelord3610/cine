<?php 
    require 'connection.php';
    class FunctionsModel extends Connection {
        public function __construct() {
            parent::__construct();
        }

        public function readAll() {
            $data = array();
            $query = "SELECT 
                id_function AS id, 
                cover, 
                films.name AS name, 
                films.description AS sinopsis, 
                director, 
                gender, 
                address, 
                places.description AS location, 
                start_date, 
                end_date, 
                capacity 
            FROM 
                functions, 
                films, 
                places 
            WHERE 
                films.id_film = functions.id_film AND 
                places.id_places = functions.id_places";

            $result = $this->conn->query($query);
            while ($row = $result->fetch_array()) {
                $data[] = (object)array(
                    'id'           => $row['id'],
                    'cover'	       => $row['cover'],
                    'name'	       => $row['name'],
                    'sinopsis'     => $row['sinopsis'],
                    'director'     => $row['director'],
                    'gender'       => $row['gender'],
                    'address'      => $row['address'],
                    'location'     => $row['location'],
                    'startDate'    => $row['start_date'],
                    'endDate'      => $row['end_date'],
                    'capacity'     => $row['capacity']
                );
            }  
            return $data;
        }

        public function geteSpecificItem($id) {
            $data = array();
            $query = "SELECT 
                id_function AS id, 
                cover, 
                films.name AS name, 
                films.description AS sinopsis, 
                director, 
                gender, 
                address, 
                places.description AS location, 
                start_date, 
                end_date, 
                capacity 
            FROM 
                functions, 
                films, 
                places 
            WHERE 
                films.id_film = functions.id_film AND 
                places.id_places = functions.id_places AND
                id_function = $id";

            $result = $this->conn->query($query);
            $row = $result->fetch_array();
            if (!empty($row)) {
                $data = (object)array(
                    'id'           => $row['id'],
                    'cover'	       => $row['cover'],
                    'name'	       => $row['name'],
                    'sinopsis'     => $row['sinopsis'],
                    'director'     => $row['director'],
                    'gender'       => $row['gender'],
                    'address'      => $row['address'],
                    'location'     => $row['location'],
                    'startDate'    => $row['start_date'],
                    'endDate'      => $row['end_date'],
                    'capacity'     => $row['capacity']
                );
            }else{
                $data = null;
            }
            return $data;
        }

        public function reservations($id){
            $data = array();
            $query = "SELECT 
            functions.id_function AS id, 
            cover, 
            films.name AS name, 
            films.description AS sinopsis, 
            director, 
            gender, 
            address, 
            places.description AS location, 
            start_date, 
            end_date, 
            capacity 
            FROM 
            functions, 
            films, 
            places
            WHERE 
            films.id_film = functions.id_film AND 
            places.id_places = functions.id_places AND
            NOT EXISTS(SELECT NULL FROM reservations WHERE functions.id_function = reservations.id_function AND id_user = $id)";
            $result = $this->conn->query($query);
            while ($row = $result->fetch_array()) {
                $data[] = (object)array(
                    'id'           => $row['id'],
                    'cover'	       => $row['cover'],
                    'name'	       => $row['name'],
                    'sinopsis'     => $row['sinopsis'],
                    'director'     => $row['director'],
                    'gender'       => $row['gender'],
                    'address'      => $row['address'],
                    'location'     => $row['location'],
                    'startDate'    => $row['start_date'],
                    'endDate'      => $row['end_date'],
                    'capacity'     => $row['capacity']
                );
            }  
            return $data;
        }

        public function setReservation($id_fucntion, $id_user){
            $query = "INSERT INTO reservations (id_function, id_user)VALUES ($id_fucntion, $id_user)";
            $this->conn->query($query);
            $query = "SELECT capacity FROM functions WHERE id_function = $id_fucntion";
            $result = $this->conn->query($query);
            $row = $result->fetch_array();
            $capacity = $row['capacity'] - 1;
            $query = "UPDATE functions SET capacity = $capacity WHERE id_function = $id_fucntion";
            $this->conn->query($query);
        }
    }
?>