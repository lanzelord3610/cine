<?php
    class Connection {
        protected $conn;
        public function __construct() {
            $this->conn = new mysqli(DB_SERVER, DB_SERVER_USERNAME, DB_SERVER_PASSWORD, DB_DATABASE, 3306);
            mysqli_set_charset($this->conn,"utf8");
        }
    }
?>    