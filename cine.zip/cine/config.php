<?php
    //CONFIGURACION DE VARIABLES ESTATICAS (PREDEFINIDAS)
    
    /******************************************/
    //TIPO: CONEXION A LA BASE DE DATOS 
    define('DB_SERVER',          'localhost');
    define('DB_SERVER_USERNAME', 'root');
    define('DB_SERVER_PASSWORD', '');
    define('DB_DATABASE',        'cine');
    /******************************************/

    /********************************************/
    // DEFINICION DE SUPER (OPCIONAL PARA PRUEBAS)
    define('SA_NAME', 'superadmin');
    define('SA_PASS', 'rootAdmin');
    /******************************************/

    date_default_timezone_set('America/Bogota');
?>