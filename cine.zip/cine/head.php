<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/main.style.css">
    <link rel="stylesheet" href="assets/css/fontawesome/css/all.css">
    <link rel="stylesheet" href="assets/css/fontawesome/css/fontawesome.css">
    <link rel="icon" type="image/jpeg" href="assets/img/logo.png">
    <script src="js/main.cine.js"></script>
    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <title>CINE-CUC</title>
</head>
<?php     
    require 'config.php';
    session_start(); 
?>