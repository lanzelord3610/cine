-- --------------------------------------------------------
-- Host:                         localhost
-- Versión del servidor:         5.7.24 - MySQL Community Server (GPL)
-- SO del servidor:              Win64
-- HeidiSQL Versión:             10.2.0.5599
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Volcando estructura de base de datos para cine
CREATE DATABASE IF NOT EXISTS `cine` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `cine`;

-- Volcando estructura para tabla cine.films
CREATE TABLE IF NOT EXISTS `films` (
  `id_film` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `cover` varchar(50) NOT NULL,
  `description` longtext NOT NULL,
  `director` varchar(50) NOT NULL,
  `gender` varchar(50) NOT NULL,
  PRIMARY KEY (`id_film`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla cine.films: ~2 rows (aproximadamente)
/*!40000 ALTER TABLE `films` DISABLE KEYS */;
INSERT INTO `films` (`id_film`, `name`, `cover`, `description`, `director`, `gender`) VALUES
	(1, 'EL DIA DEL FIN DEL MUNDO', 'caratula1.jpg', 'Cuando el mundo es consciente de que el asteroide más grande de la historia va a impactar en la Tierra y aniquilar todo rastro de vida, los gobiernos de todo el mundo realizan un sorteo en el cual los afortunados podrán sobrevivir en refugios secretos. Esta decisión desata un caos a nivel mundial. Muchos tendrán que emprender un peligroso viaje donde se enfrentarán a los más imponentes peligros de la naturaleza, lo que les obligará a encontrar la manera de mantenerse unidos mientras encuentran la forma de sobrevivir', 'Ric Roman Waugh', 'Acción, Thriller'),
	(2, 'Mujer Maravilla 1984', 'caratula2.jpg', 'Avancemos rápidamente a la década de 1980 cuando la próxima aventura en la pantalla grande de Mujer Maravilla la encuentra frente a dos enemigos completamente nuevos: Max Lord y Cheetah.', 'Patty Jenkins', 'Ficcion, Acción');
/*!40000 ALTER TABLE `films` ENABLE KEYS */;

-- Volcando estructura para tabla cine.functions
CREATE TABLE IF NOT EXISTS `functions` (
  `id_function` int(10) NOT NULL AUTO_INCREMENT,
  `id_film` int(10) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `id_places` int(10) NOT NULL,
  `capacity` int(10) NOT NULL,
  PRIMARY KEY (`id_function`),
  KEY `id_film` (`id_film`),
  KEY `id_place` (`id_places`),
  CONSTRAINT `FK_functions_films` FOREIGN KEY (`id_film`) REFERENCES `films` (`id_film`),
  CONSTRAINT `FK_functions_places` FOREIGN KEY (`id_places`) REFERENCES `places` (`id_places`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla cine.functions: ~2 rows (aproximadamente)
/*!40000 ALTER TABLE `functions` DISABLE KEYS */;
INSERT INTO `functions` (`id_function`, `id_film`, `start_date`, `end_date`, `id_places`, `capacity`) VALUES
	(1, 1, '2021-01-15', '2021-01-15', 1, 7),
	(2, 2, '2021-01-15', '2021-01-15', 1, 8);
/*!40000 ALTER TABLE `functions` ENABLE KEYS */;

-- Volcando estructura para tabla cine.places
CREATE TABLE IF NOT EXISTS `places` (
  `id_places` int(10) NOT NULL AUTO_INCREMENT,
  `address` varchar(50) NOT NULL,
  `description` varchar(50) NOT NULL,
  PRIMARY KEY (`id_places`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla cine.places: ~1 rows (aproximadamente)
/*!40000 ALTER TABLE `places` DISABLE KEYS */;
INSERT INTO `places` (`id_places`, `address`, `description`) VALUES
	(1, 'Calle 53 # 46 - 192', 'Centro Comercial Portal Del Prado');
/*!40000 ALTER TABLE `places` ENABLE KEYS */;

-- Volcando estructura para tabla cine.reservations
CREATE TABLE IF NOT EXISTS `reservations` (
  `id_reservation` int(10) NOT NULL AUTO_INCREMENT,
  `id_function` int(10) NOT NULL,
  `id_user` int(10) NOT NULL,
  PRIMARY KEY (`id_reservation`),
  KEY `id_function` (`id_function`),
  KEY `id_user` (`id_user`),
  CONSTRAINT `FK_reservations_functions` FOREIGN KEY (`id_function`) REFERENCES `functions` (`id_function`),
  CONSTRAINT `FK_reservations_users` FOREIGN KEY (`id_user`) REFERENCES `users` (`id_users`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla cine.reservations: ~5 rows (aproximadamente)
/*!40000 ALTER TABLE `reservations` DISABLE KEYS */;
INSERT INTO `reservations` (`id_reservation`, `id_function`, `id_user`) VALUES
	(12, 1, 2),
	(15, 1, 4);
/*!40000 ALTER TABLE `reservations` ENABLE KEYS */;

-- Volcando estructura para tabla cine.type_user
CREATE TABLE IF NOT EXISTS `type_user` (
  `id_type_user` int(10) NOT NULL AUTO_INCREMENT,
  `description` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_type_user`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla cine.type_user: ~2 rows (aproximadamente)
/*!40000 ALTER TABLE `type_user` DISABLE KEYS */;
INSERT INTO `type_user` (`id_type_user`, `description`) VALUES
	(1, 'Administrador'),
	(2, 'Usuario');
/*!40000 ALTER TABLE `type_user` ENABLE KEYS */;

-- Volcando estructura para tabla cine.users
CREATE TABLE IF NOT EXISTS `users` (
  `id_users` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `user` varchar(10) NOT NULL,
  `email` varchar(250) NOT NULL,
  `pass` varchar(250) NOT NULL,
  `img` varchar(50) DEFAULT NULL,
  `id_type_user` int(10) NOT NULL,
  `registration_date` datetime NOT NULL,
  PRIMARY KEY (`id_users`),
  KEY `id_type_user` (`id_type_user`),
  CONSTRAINT `FK_users_type_user` FOREIGN KEY (`id_type_user`) REFERENCES `type_user` (`id_type_user`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla cine.users: ~3 rows (aproximadamente)
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id_users`, `name`, `last_name`, `user`, `email`, `pass`, `img`, `id_type_user`, `registration_date`) VALUES
	(1, 'Juan', 'Peña', 'lanzelord', 'jpena3610@gmail.com', 'cd13042aa67f69cd444dcec16a039921ef2208dc986c7b387bf9b6090c7c64595972d1294e069fbb28cf4ded084e5c546f9081ec46a345d4363e1a6235a2f1a2', 'default.jpg', 1, '2021-01-14 11:59:40'),
	(2, 'Pedro', 'Ramos', 'pedro98', 'perdo98@gmail.com', 'ba3253876aed6bc22d4a6ff53d8406c6ad864195ed144ab5c87621b6c233b548baeae6956df346ec8c17f5ea10f35ee3cbc514797ed7ddd3145464e2a0bab413', 'default.jpg', 2, '2021-01-15 11:09:18'),
	(4, 'Juan', 'Peña', 'juanpena25', 'lanzelord3610@gmail.com', 'd9e6762dd1c8eaf6d61b3c6192fc408d4d6d5f1176d0c29169bc24e71c3f274ad27fcd5811b313d681f7e55ec02d73d499c95455b6b5bb503acf574fba8ffe85', 'default.jpg', 2, '2021-01-16 06:08:02');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
