window.onload = ()=>{
    const el = document.querySelector('.user-data')
    if (el) {
        el.addEventListener('click', function(){
            if (this.parentNode.classList.contains('close-menu')) {
                this.parentNode.classList.remove('close-menu')
                this.parentNode.classList.add('open-menu')
            }else{
                this.parentNode.classList.remove('open-menu')
                this.parentNode.classList.add('close-menu')
            }
        })   
    }

    try {
        $(document).on("click", function(e) {
            var container = $(".user-content");
            if (!container.is(e.target) && container.has(e.target).length === 0) {
                try {
                    el.parentNode.classList.remove('open-menu')
                    el.parentNode.classList.add('close-menu')
                }catch (error){
                    //console.log(error)
                }
            }
        });
    } catch (error) {
        //console.log(error)
    }

    const element = document.querySelector('#form');
    try {
        element.addEventListener('submit', event => {
            event.preventDefault();
            setTimeout(function() {
                document.querySelector('#form').submit()
            }, 600)
        });
    } catch (error) {
        //console.log(error)
    }

    function getCards() {
        $.ajax({
            type: "POST",
            url: 'ajax/card.php',
            async: false,
            data: {
                action: 0
            },
            success: function(response) {
               $('.container').html(response) 
            }
        });
    }

    function getJasonCard(tipe, id) {
        let data
        $.ajax({
            type: "POST",
            url: 'ajax/card.php',
            async: false,
            data: {
                action: 1,
                values: {tipe: tipe, id: id}
            },
            success: function(response) {
                data = JSON.parse(response)
            }
        });
        return data;
    }

    function reservate(id) {
        let data
        $.ajax({
            type: "POST",
            url: 'ajax/card.php',
            async: false,
            data: {
                action: 2,
                values: {id: id}
            },
            success: function(response) {
                data = JSON.parse(response)
            }
        });
        return data;
    }

    $(document).on('click', '.card', function() {
        id = this.getAttribute('data-id')
        let obj = getJasonCard(2, id)
        $('#cover').attr('src', 'assets/covers/'+obj.cover)
        $('#modalTitleFilm').text(obj.name)
        $('#exampleModalLongTitle').text(obj.name)
        $('#gender').text(obj.gender)
        $('.description').text(obj.sinopsis)
        $('#startDate').text('Fecha de inicio: '+obj.startDate)
        $('#endDate').text('Fecha de finalización: '+obj.endDate)
        $('#location').text('Lugar: '+obj.location)
        $('#address').text('Dirección: '+obj.address)
        $('#capacity').text('Cupos disponibles: '+obj.capacity)
        $('#reservar').attr('data-id', obj.id)
    })

    $(document).on('click', '#reservar', function() {
        id = this.getAttribute('data-id')
        data = reservate(id)
        if (data.menssage == 'error') {
            location.href = 'login.php';
        }
        getCards()
        $('#modal').modal("hide");
    })

    function getFunctions() {
        let data
        $.ajax({
            type: "POST",
            url: 'ajax/card.php',
            async: false,
            data: {
                action: 1,
                values: {tipe: 1}
            },
            success: function(response) {
                data = JSON.parse(response)
                array = "";
                if (data == null) {
                    array = '<tr><td colspan="6" style="text-align: center;vertical-align: middle;">No se encontraron registros coincidentes</td></tr>';
                }
                for (const key in data) {
                    card = data[key]
                    array += '<tr>'
                    array += '<td>'+card.name+'</td>'
                    array += '<td>'+card.startDate+'</td>'
                    array += '<td>'+card.endDate+'</td>'
                    array += '<td>'+card.capacity+'</td>'
                    array += '<td>'+card.location+'</td>'
                    array += '<td><button class="basic-button orange-button" data-id="'+card.id+'" id="edit" data-toggle="modal" data-target="#functionModal">Editar</button></td>'
                    array += '<td><button class="basic-button red-button" data-id="'+card.id+'" id="cancel" data-toggle="modal" data-target="#functionModal">Cancelar</button></td>'
                    array += '</tr>'
                }
                $('#tableFunctions tbody').html(array);
            }
        });
        return data;
    }
    getFunctions()
    getCards();
    
    $(document).on('input', '.input-number', function() {
        this.value = this.value.replace(/[^0-9]/g, '');
    });

    $(document).on('click', '#add', function() {
        $('#ModalLongTitle').text('Añadir una funcion')
        $.ajax({
            type: "POST",
            url: 'ajax/add.php',
            async: false,
            data: {
                action: 2,
                values: {id: 1}
            },
            success: function(response) {
                $('.modal-body').html(response)
            }
        });
    })
}