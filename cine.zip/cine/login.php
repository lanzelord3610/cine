<?php 
    require 'head.php';
    require 'controller/validate-login.php';
    if (isset($_POST['user']) && isset($_POST['pass'])) {
        $user = $_POST['user'];
        $pass = $_POST['pass'];
        $objlogin = new ValidateLoginController();
        $data = $objlogin->login($user, $pass);
        if ($data->session) {
            $objlogin->setDataSession();
        }
    }
    if (isset($_SESSION['session'])) {
        if ($_SESSION['session']) {
            header('Location: index.php');
        }
    }
?>
<body>
    <aside class="flex-container">
        <section class="form">
            <div class="mb-form">
                <a href="index.php"><img src="assets/img/logo.png"></a>
                <h1>Inicia Sessión</h1>
                <form action="login.php" method="post" id="form">
                    <div class="input-group">
                        <label for="">Usuario</label>
                        <input type="user" name="user" id="user" placeholder="Usuario o Correo" pattern=".{6,}" title="8 o más caracteres" required>
                    </div>
                    <div class="input-group">
                        <label for="">Contraseña</label>
                        <input type="password" name="pass" id="pass" placeholder="Contraseña" pattern=".{6,}" title="8 o más caracteres" required>
                    </div>
                    <button type="submit" class="button">Inicia Sessión</button>
                </form>
                <p>¿No tienes una cuenta? <a href="sing-in.php">Registrate</a></p>
            </div>
        </section>
        <section class="content-img">
        </section>
    </aside>
</body>
</html>