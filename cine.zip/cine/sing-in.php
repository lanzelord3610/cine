<?php 
    require 'head.php';
    require 'controller/validate-login.php';
    if (isset($_POST['name']) && isset($_POST['lastName']) && isset($_POST['user']) && isset($_POST['email']) && isset($_POST['pass']) && isset($_POST['rpass'])) {
        $data = (object)array(
            'name' => $_POST['name'],
            'lastName' => $_POST['lastName'],
            'user' => $_POST['user'],
            'email' => $_POST['email'],
            'pass' => $_POST['pass'],
            'rpass' => $_POST['rpass'],
        );
        if ($data->pass == $data->rpass) {
            $objlogin = new ValidateLoginController();
            $result = $objlogin->registration($data);
            if ($result->error) {
                echo '<div class="notify-error"><i class="fa fa-times-circle"></i>'.$result->menssage.'</div>';
            }else{
                header('Location: login.php'); 
            }
        }else{
            echo '<div class="notify-error"><i class="fa fa-times-circle"></i>las contraseñas no coinciden</div>';
        }
    }
    if (isset($_SESSION['session'])) {
        if ($_SESSION['session']) {
            header('Location: index.php');
        }
    }
?>
<body>
    <aside class="flex-container">
        <section class="form">
            <div class="mb-form">
                <a href="index.php"><img src="assets/img/logo.png"></a>
                <h1>Registrarse</h1>
                <form action="sing-in.php" id="form" method="post">
                    <div class="input-group">
                        <label for="">Nombre</label>
                        <input type="text" name="name" placeholder="Nombre" required>    
                    </div>
                    <div class="input-group">
                        <label for="">Apellido</label>
                        <input type="text" name="lastName" placeholder="Apellido" required>
                    </div>
                    <div class="input-group">
                        <label for="">Usuario</label>
                        <input type="user" name="user" placeholder="Usuario" pattern=".{6,}" title="6 o más caracteres" required>
                    </div>
                    <div class="input-group">
                        <label for="">Correo</label>
                        <input type="email" name="email" placeholder="prueba@ejemplo.com" required>
                    </div>
                    <div class="input-group">
                        <label for="">Contraseña</label>
                        <input type="password" name="pass" placeholder="Ingrese 8 caracteres o más" pattern=".{8,}" title="8 caracteres o más" required>
                    </div>
                    <div class="input-group">
                        <label for="">Repita su contraseña</label>
                        <input type="password" name="rpass" placeholder="Repita su contraseña" required>
                    </div>
                    <button type="submit" class="button">Registrarse</button>
                </form>
                <p>¿Ya tienes una cuenta? <a href="login.php">Inicia Sessión</a></p>
            </div>
        </section>
        <section class="content-img">
        </section>
    </aside>
</body>
</html>