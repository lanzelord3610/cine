<?php 
    require 'model/validate-login.php';
    class ValidateLoginController extends ValidateLoginModel{
        public function __construct() {
            parent::__construct();
        }

        public function login($user, $pass){
            $validate = $this->validate($user, hash('sha512', $pass));
            if ($validate) {
                return (object)array('menssage'=> 'Se inicio session correctamente', 'session' => true);
            }else{
                return (object)array('menssage'=> 'No inicio session correctamente', 'session' => false);
            }
        }

        public function setDataSession(){
            $data = $this->getData();
            $_SESSION['session'] = true;
            $_SESSION['data-user'] = $data;
        }

        public function registration($data){
            $validate = $this->register($data);
            if ($validate) {
                return (object)array('menssage'=> 'Registro exitoso', 'error' => false);
            }else{
                return (object)array('menssage'=> 'el nombre de usuario o el correo ya estan registrados', 'error' => true);
            }
        }
    }
    
?>