<?php 
    require '../model/functions-model.php';
    class FunctionsController extends FunctionsModel {
        public function __construct() {
            parent::__construct();
        }

        public function getCards() {
            session_start();
            if (isset($_SESSION['data-user'])) {
                $dataUser = $_SESSION['data-user'];
                $cards = $this->reservations($dataUser->ID);
                foreach ($cards as $card) {
                    if ($card->capacity > 0) {
                        echo '<div class="card" data-toggle="modal" data-target="#modal" data-id="'.$card->id.'">';
                        echo '<img src="assets/covers/'.$card->cover.'" alt="caratula">';
                        echo '<h3>'.$card->name.'</h3>';
                        echo '<small>'.$card->gender.'</small>';
                        echo '</div>';
                    }                    
                }

                if (empty($cards)) {
                    echo 'no se encontraron funciones disponibles';
                }
            }else{
                $cards = $this->readAll();
                foreach ($cards as $card) {
                    if ($card->capacity > 0) {
                        echo '<div class="card" data-toggle="modal" data-target="#modal" data-id="'.$card->id.'">';
                        echo '<img src="assets/covers/'.$card->cover.'" alt="caratula">';
                        echo '<h3>'.$card->name.'</h3>';
                        echo '<small>'.$card->gender.'</small>';
                        echo '</div>';
                    }
                }
            }
        }

        public function getJson($data){
            $obj = $data;
            switch ($obj->tipe) {
                case 1:
                    $json = $this->readAll();
                    echo json_encode($json);
                    break;
                case 2:
                    $json = $this->geteSpecificItem($obj->id);
                    echo json_encode($json);
                    break;
                default:
                    echo json_encode('');
                    break;
            }
        }

        public function reservate($data){
            session_start();
            if (isset($_SESSION['data-user'])) {
                $user = $_SESSION['data-user']->ID;
                $this->setReservation($data->id, $user);
                echo json_encode((object)array('menssage'=>'exito'));
            }else{
                echo json_encode((object)array('menssage'=>'error'));
            }
        }
    }
?>