<?php
    require_once '../config.php';
    require_once '../model/connection.php';
    class AddFunction extends Connection
    {
        public function __construct() {
            parent::__construct();
        }

        public function addInterface()
        {
            $query = 'SELECT * FROM films';
            $result = $this->conn->query($query);
            $select[0] = '<select id="film">';
            while ($row = $result->fetch_array()) {
                $select[0] .= '<option value="'.$row['id_film'].'">'.ucfirst(strtolower($row['name'])).'</option>';
            }
            $select[0] .= '</select>';

            $query = 'SELECT * FROM places';
            $result = $this->conn->query($query);
            $select[1] = '<select id="lugar">';
            while ($row = $result->fetch_array()) {
                $select[1] .= '<option value="'.$row['id_places'].'">'.ucfirst(strtolower($row['description'])).'</option>';
            }
            $select[1] .= '</select>';

            $element = '<div class="flex-content">';
            $element .= '<label>Pelicula</label>';
            $element .= $select[0];
            $element .= '<label>Lugar</label>';
            $element .= $select[1];
            $element .= '<label>Fecha de inicio</label>';
            $element .= '<input type="date" id="dateStart">';
            $element .= '<label>Fecha de finalizacion</label>';
            $element .= '<input type="date" id="dateEnd">';
            $element .= '<label>Cupos</label>';
            $element .= '<input type="number" class="input-number" id="capacity">';
            $element .= '</div>';

            return $element;
        }   
    }

    $objAdd = new AddFunction();
    echo $objAdd->addInterface();
?>