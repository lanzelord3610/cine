<?php 
    require_once '../config.php';
    require_once '../controller/functions-controller.php';
    if(isset($_POST['action'])) {
        $objCard = new FunctionsController();
        $action = $_POST['action'];
        $values = (isset($_POST['values'])) ? (object)$_POST['values'] : null;
        //print_r($values);
        switch ($action) {
            case 0: $objCard->getCards();; break;
            case 1: $objCard->getJson($values); break;
            case 2: $objCard->reservate($values); 
            default: # code... 
            break;
        }
    }
    
    
?>